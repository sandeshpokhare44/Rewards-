package com.rewards.dto;

public class RewardsDTO {
	private Integer month;
	private Long monthPoints;

	public Integer getMonth() {
		return month;
	}
	public void setMonth(Integer month) {
		this.month = month;
	}
	public Long getMonthPoints() {
		return monthPoints;
	}
	public void setMonthPoints(Long monthPoints) {
		this.monthPoints = monthPoints;
	}


}
